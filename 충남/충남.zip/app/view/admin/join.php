<div id="member-form">
	<div class="wrap">
		<h1>회원가입</h1>
		<form method="post">
			<input type="hidden" name="action" value="join">
			<label for="name"><span>성명</span><input type="text" name="name" id="name" required></label>
			<label for="id"><span>아이디</span><input type="text" name="id" id="id" required></label>
			<label for="pw"><span>패스워드</span><input type="password" name="pw" id="pw" required></label>
			<label for="email"><span>이메일</span><input type="text" name="email" id="email" required></label>
			<button type="submit" class="btn">회원 가입</button>
		</form>
	</div>
</div>