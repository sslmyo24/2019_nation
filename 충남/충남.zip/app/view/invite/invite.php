<div id="member-form">
	<div class="wrap">
		<form method="post" enctype="multipart/form-data">
			<input type="hidden" name="action" value="invite">
			<label for="name"><span>행사명</span><input type="text" name="name" id="name"></label>
			<label for="code"><span>고유코드</span><input type="text" name="code" id="code"></label>
			<label for="file"><span>파일</span><input type="file" name="file" id="file"></label>
			<button type="submit" class="btn">전송</button>
		</form>
	</div>
</div>